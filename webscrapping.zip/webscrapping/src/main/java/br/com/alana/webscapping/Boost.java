package br.com.alana.webscapping;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Boost {

	public static void main(String[] args) throws IOException {

		String url = "https://lists.boost.org/Archives/boost/2022/08/253317.php";
		Document doc = Jsoup.connect(url).get();
		try {
			doc = Jsoup.connect(url).get();
		} catch (IOException e) {
			e.printStackTrace();
		}

		Element element = doc.select("body p").first();
		String frase = element.text();

		// Retira a tag EM
		element.select("em").remove();
		frase = element.text();

		// Divide a frase em duas partes
		int index = frase.length() / 2;
		String nome = frase.substring(0, index - 4);
		String data = frase.substring(index - 2);

		System.out.println("Autor: " + nome);
		System.out.println("Date:" + data);

		Elements title = doc.select("title");
		for (Element t : title) {
			String texto = t.text();
			System.out.println("Assunto: " + texto);
		}

		Elements paragrafos = doc.select("p");
		for (Element paragrafo : paragrafos) {
			String texto = paragrafo.text().trim();
			if (!texto.isEmpty()) {
				System.out.println("corpo do e-mail:" + texto);
			}
		}

//		Element lista = doc.select("ul").first();
//		Element item = lista.select("li").get(3);
//		String texto = item.text();
//		System.out.println("Respondente: " + texto);

		String termoBuscado = "Reply";
		try {
			String html = doc.html();
			if (html.contains(termoBuscado)) {
				System.out.println("Esse é o e-mail original");
			} else {
				System.out.println("Esse é o e-mail de resposta");
			}

		} finally {
		}
	}
}
